#!/usr/bin/env python3
"""
抖音爆款作品搜索脚本
使用 data_source 混合模式（API + Mock 回退）
用法: python3 search_douyin.py "<关键词>" [--start-date YYYY-MM-DD] [--end-date YYYY-MM-DD]
"""

import sys
import os
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '_shared'))
from data_source import fetch_with_mock, get_api_key


def format_articles(articles: list) -> list:
    """将原始 articles 数据转换为统一格式"""
    items = []
    for art in articles:
        items.append({
            "title": art.get("title", "").strip(),
            "author": art.get("accountName", "").strip(),
            "like_count": art.get("likeCount", 0) or 0,
            "comment_count": art.get("commentCount", 0) or 0,
            "share_count": art.get("shareCount", 0) or 0,
            "collect_count": art.get("collectCount", 0) or 0,
            "work_url": art.get("workUrl", ""),
            "publish_time": art.get("publishTime", ""),
            "follower_count": art.get("followerCount", 0) or 0,
        })
    items.sort(key=lambda x: x["like_count"], reverse=True)
    return items


def search(keyword: str, start_date: str = "", end_date: str = "") -> dict:
    """Search using data_source (API with mock fallback)."""
    payload = {"keyword": keyword, "source": "douyin-search"}
    if start_date:
        payload["startDate"] = start_date
    if end_date:
        payload["endDate"] = end_date

    result = fetch_with_mock("dy/search/search", payload, keyword=keyword)

    data = result.get("data") or {}
    if result.get("code") not in (0, None):
        print(f"[info] Search result: {result.get('msg', '')}", file=sys.stderr)

    return {
        "articles": format_articles(data.get("articles") or []),
        "latestHotArticles": format_articles(data.get("latestHotArticles") or []),
        "hotTopics": data.get("hotTopics") or [],
    }


def main():
    import argparse

    parser = argparse.ArgumentParser(description="抖音爆款作品搜索脚本")
    parser.add_argument("keyword", help="搜索关键词")
    parser.add_argument("--start-date", "-s", default="", help="起始日期 YYYY-MM-DD")
    parser.add_argument("--end-date", "-e", default="", help="结束日期 YYYY-MM-DD")
    args = parser.parse_args()

    keyword = args.keyword.strip()
    if not keyword:
        print("[error] 关键词不能为空", file=sys.stderr)
        sys.exit(1)

    result = search(keyword, start_date=args.start_date, end_date=args.end_date)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
