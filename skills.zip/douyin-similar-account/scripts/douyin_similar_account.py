#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音相似账号推荐脚本
功能：调用红狐API查询抖音对标账号和头部账号，输出对标账号信息+近期作品+深度分析
接口文档：POST /dyUser/querySimilarAccounts
"""

import argparse
import json
import os
import platform
import re
import urllib.error
import urllib.parse
import urllib.request


# ============================================================
# API Key 管理
# ============================================================

def get_api_key(cli_key=None):
    """Get API key from shared module."""
    from data_source import get_api_key as _get_ak
    return _get_ak(cli_key)


def _read_api_key_from_unix_shell_config():
    config_files = [
        os.path.expanduser("~/.zshrc"),
        os.path.expanduser("~/.bashrc"),
        os.path.expanduser("~/.bash_profile"),
        os.path.expanduser("~/.profile"),
    ]
    for config_file in config_files:
        if not os.path.isfile(config_file):
            continue
        try:
            with open(config_file, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    m = re.match(r'^(?:export\s+)?REDFOX_API_KEY=["\']?(.+?)["\']?\s*$', line)
                    if m:
                        return m.group(1)
        except (IOError, OSError):
            continue
    return None


def _read_api_key_from_windows():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment")
        try:
            value, _ = winreg.QueryValueEx(key, "REDFOX_API_KEY")
            if value:
                return str(value)
        finally:
            winreg.CloseKey(key)
    except (ImportError, OSError):
        pass

    ps_profile_paths = [
        os.path.join(os.path.expanduser("~"), "Documents", "WindowsPowerShell", "Microsoft.PowerShell_profile.ps1"),
        os.path.join(os.path.expanduser("~"), "Documents", "PowerShell", "Microsoft.PowerShell_profile.ps1"),
    ]
    for profile_path in ps_profile_paths:
        if not os.path.isfile(profile_path):
            continue
        try:
            with open(profile_path, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    line = line.strip()
                    m = re.match(r'\$env:REDFOX_API_KEY\s*=\s*["\']?(.+?)["\']?\s*$', line)
                    if m:
                        return m.group(1)
        except (IOError, OSError):
            continue
    return None


# ============================================================
# API 调用
# ============================================================

def query_similar_accounts(accountId=None, accountName=None):
    """调用API查询对标账号和头部账号

    接口文档：POST /dyUser/querySimilarAccounts
    两种查询模式：
      1. 传入accountId：通过账号ID查询该账号信息并匹配对标账号
      2. 传入accountName：通过账号名称查询该账号信息并匹配对标账号

    响应字段：
      data.currentAccount: DyUserInfoVO 当前账号信息（含redfoxIndex、similarAccounts）
      data.benchmarkAccounts: List<DySimilarAccountDetailVO> 对标账号列表（红狐指数向上最近的5个）
      data.topAccounts: List<DySimilarAccountDetailVO> 头部账号列表（同分类红狐指数倒序前5）
      账号详情 DySimilarAccountDetailVO: nickname, url, followerCount, uid,
        awemeCount, totalFavorited, awemeCountSeven, interactiveCountSeven,
        interactiveCountThirty, lastAwemeCreateTime, redfoxIndex, works[]
      作品 DyWorkVO: awemeId, title, coverUrl, desc, createTime, diggCount,
        commentCount, shareCount, playCount, interactiveCount, workUrl
    """
    credential = get_api_key()

    url = "https://redfox.hk/story/api/dyUser/querySimilarAccounts"
    headers = {
        "Content-Type": "application/json",
        "X-API-KEY": credential
    }

    payload = {}
    if accountId:
        payload["accountId"] = accountId
    if accountName:
        payload["accountName"] = accountName
    payload["source"] = "抖音相似账号推荐-GitHub"

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise Exception(
        "REDFOX_API_KEY not configured. The script requires this environment variable to function."
    )
    lines.append("")
    lines.append(f"1. 回复抖音号（在抖音个人主页显示的ID，如 {account_id}_1234），即可进行账号收录。30分钟后将自动为您推送相似账号报告~")
    lines.append("2. 下次再说；")
    return "\n".join(lines)


def format_subscription_prompt(account_name):
    """查询结果末尾输出订阅服务提示文案"""
    lines = []
    lines.append(f"是否订阅「{account_name}」的相似账号最新信息推送？")
    lines.append("")
    lines.append("1. 每日下午19点推送最新数据。可自行选择推送频率和时间~")
    lines.append("2. 暂不需要")
    return "\n".join(lines)


def sync_user_notes(account_id):
    """调用API触发账号数据同步收录

    接口文档：POST /dyUser/syncUserNotes
    将指定账号加入抖音待同步队列，系统会异步拉取该账号的文章/作品数据。
    """
    credential = get_api_key()

    url = "https://redfox.hk/story/api/dyUser/syncUserNotes"
    headers = {
        "Content-Type": "application/json",
        "X-API-KEY": credential
    }

    payload = {
        "accountId": account_id,
        "source": "抖音相似账号推荐"
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8")) if resp.read else None
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise Exception(
        "REDFOX_API_KEY not configured. The script requires this environment variable to function."
    ))
        else:
            print(f"查询失败: {error_msg}")


if __name__ == "__main__":
    main()