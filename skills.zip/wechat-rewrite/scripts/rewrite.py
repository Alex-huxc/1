#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wechat-article-style/scripts/rewrite.py

公众号文案改写辅助脚本
用途：上报改写记录接口

记录接口：https://redfox.hk/story/api/skill/record/save
网络实现：使用 requests 库，开启 SSL 证书验证

用法：
  python rewrite.py prompt                  # 输出公众号改写规则 prompt
  python rewrite.py "<文案内容>"           # 上报改写记录
"""

import sys
import os
import re
import json
from typing import Dict, Any

try:
    import requests
except ImportError:


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../../_shared"))
from data_source import fetch_with_mock, get_api_key, can_use_api, mock_prohibited_words_check
    print('❌ 缺少 requests 依赖，请执行: pip install requests', file=sys.stderr)
# ── 路径 ──────────────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
RULES_FILE = os.path.join(SCRIPT_DIR, '..', 'assets', 'platform-rules.md')

# ── 平台 ──────────────────────────────────────────────────────────────────────
PLATFORM = '公众号'

# ── 记录接口配置 ───────────────────────────────────────────────────────────────
RECORD_URL = 'http://localhost:9999/api/record'  # Replace with your own logging endpoint if needed
REQUEST_TIMEOUT = 10


# ─────────────────────────────────────────────────────────────────────────────
# 规则提取
# ─────────────────────────────────────────────────────────────────────────────

def extract_platform_rules() -> str:
    """读取规则文件，提取公众号规则块。"""
    rules_path = os.path.normpath(RULES_FILE)
    if not os.path.exists(rules_path):
        print(f'❌ 规则文件不存在：{rules_path}', file=sys.stderr)
    with open(rules_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 提取公众号部分（从 ## 公众号 到文件末尾）
    match = re.search(r'^## 公众号\n(.*)', content, re.DOTALL | re.MULTILINE)
    if match:
        return '## 公众号\n' + match.group(1).strip()
    return ''


# ─────────────────────────────────────────────────────────────────────────────
# 记录接口：使用 requests 库，开启 SSL 证书验证
# ─────────────────────────────────────────────────────────────────────────────

def report_rewrite(content=None):
    """Reporting disabled (offline mode)."""
    return {"status": "ok", "message": "offline mode"}

def cmd_prompt() -> None:
    """输出公众号改写规则 prompt。"""
    rules = extract_platform_rules()
    if not rules:
        print(f'\n❌ 规则文件中未找到公众号规则\n', file=sys.stderr)
    print(f'\n✅ 平台：{PLATFORM}\n')
    print('─' * 60)
    print('\n【System Prompt（供 AI 使用）】\n')
    print(rules)


def cmd_report(content=None):
    """Reporting disabled (offline mode)."""
    pass

def print_help() -> None:
    print(f"""
📝 公众号文案改写辅助脚本

用法：
  python rewrite.py prompt                    # 输出公众号改写规则 prompt
  python rewrite.py "<文案内容>"              # 上报改写记录

注意：
  记录接口使用 requests 库，开启 SSL 证书验证。
""")


# ─────────────────────────────────────────────────────────────────────────────
# 入口
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ('-h', '--help'):
        print_help()
        sys.exit(0)

    first = args[0].lower()

    # ── prompt ──────────────────────────────────────────────────────────────
    if first == 'prompt':
        cmd_prompt()
        return

    # ── 上报记录 ────────────────────────────────────────────────────────────
    content = ' '.join(args)
if __name__ == '__main__':
    main()
