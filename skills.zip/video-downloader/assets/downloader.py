#!/usr/bin/env python3
"""
Qoder Video Downloader - API 版本
使用 redfox.hk API 解析并下载无水印视频/图文
支持：抖音、小红书、快手、B站

Usage:
    python3 downloader.py <url> [--api-key <key>] [--output-dir <path>]
"""

import argparse
import json
import os
import re
import sys
import warnings
from pathlib import Path

import requests

# Suppress urllib3 OpenSSL warning on macOS
warnings.filterwarnings("ignore", category=Warning)
warnings.filterwarnings("ignore", message=".*NotOpenSSLWarning.*")

API_URL = ""  # Now using shared data_source module (set via REDFOX_API_BASE env var)
CONFIG_DIR = Path.home() / ".qoder" / "apis"
CONFIG_FILE = CONFIG_DIR / "redfox.json"

ENV_KEY = "REDFOX_API_KEY"
PUBLIC_API_KEY = ""

PLATFORM_MAP = {
    "dy": "抖音",
    "xhs": "小红书",
    "xhsw": "小红书",
    "ks": "快手",
    "bili": "B站",
}

GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def info(msg):
    print(f"{GREEN}[✓]{RESET} {msg}")


def warn(msg):
    print(f"{YELLOW}[!]{RESET} {msg}")


def error(msg):
    print(f"{RED}[✗]{RESET} {msg}")


def step(msg):
    print(f"{CYAN}[→]{RESET} {msg}")


def get_api_key(cli_key=None):
    """Get API key from shared module."""
    from data_source import get_api_key as _get_ak
    return _get_ak(cli_key)


def save_api_key(api_key):
    """Persist API key to config file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps({"api_key": api_key}, indent=2))
    os.chmod(CONFIG_FILE, 0o600)  # secure file permissions
    info(f"API Key saved to {CONFIG_FILE}")


def sanitize_filename(name):
    """Remove or replace characters unsafe for filenames."""
    if not name:
        return None
    name = re.sub(r'[\\/*?:"<>|]', "", name)
    name = name.strip().replace(" ", "_")
    name = name[:120]  # limit length
    return name or None


def download_file(session, url, filepath, desc="Downloading"):
    """Download a file with progress display."""
    try:
        resp = session.get(url, stream=True, timeout=120)
        resp.raise_for_status()

        total = int(resp.headers.get("content-length", 0))
        downloaded = 0

        with open(filepath, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = int(downloaded * 100 / total)
                        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
                        print(f"\r  {bar} {pct}%", end="", flush=True)
        print()
        return True

    except requests.exceptions.RequestException as e:
        error(f"Download failed: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="短视频下载器 - 使用 redfox.hk API 下载无水印视频",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""REDFOX_API_KEY (set via environment variable)""",
    )
    parser.add_argument("url", help="视频/图文链接")
    parser.add_argument("--api-key", help="API Key（格式 ark_xxx，不传则读取环境变量或配置文件）")
    parser.add_argument("-o", "--output-dir", help="输出目录（默认 ~/Downloads/QoderVideos）")
    parser.add_argument(
        "--save-key",
        action="store_true",
        help="将本次传入的 API Key 保存到配置文件",
    )

    args = parser.parse_args()

    # ── Banner ──
    banner = f"""{CYAN}{BOLD}
  ╔══════════════════════════════════════╗
  ║     Qoder Video Downloader (API)     ║
  ║     视频下载去水印工具          ║
  ╚══════════════════════════════════════╝{RESET}
"""
    print(banner)

    # ── API Key ──
    api_key = get_api_key(cli_key=args.api_key)
    if api_key == PUBLIC_API_KEY:


    # Save key if requested
    if args.save_key:
        save_api_key(api_key)

    # ── URL ──
    url = args.url.strip().strip('"').strip("'")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    step(f"URL: {url}")

    # ── Call API ──
    step("Calling redfox.hk API...")

    session = requests.Session()
    session.headers.update({
        "Content-Type": "application/json",
        "X-API-KEY": (api_key if api_key else ""),
    })

    try:
        resp = session.post(API_URL, json={"url": url, "source": "短视频下载器-GitHub"}, timeout=30)
        result = resp.json()
    except requests.exceptions.RequestException as e:
        error(f"API request failed: {e}")
    except json.JSONDecodeError:
        error(f"API returned invalid JSON: {resp.text[:200]}")
    code = result.get("code")
    msg = result.get("msg", "")

    # 成功 code 以 2 开头（如 200、2000），其余为错误
    if not str(code).startswith("2"):
        if code == 3106:
            error("缺少 API Key")
        elif code == 3107:
            error("API Key 无效或已失效，请检查是否正确")

        elif code == 400:
            error(f"请求参数错误: {msg}")
        else:
            error(f"API error (code {code}): {msg}")
    data = result.get("data")
    if not data:
        error("API returned empty data")
    aweme_type = data.get("awemeType")
    platform = data.get("platform", "unknown")
    title = data.get("title", "untitled")

    print()
    info(f"Platform: {PLATFORM_MAP.get(platform, platform)}")
    info(f"Title: {title[:80]}")

    # ── Output directory ──
    output_dir = args.output_dir or str(Path.home() / "Downloads" / "QoderVideos")
    os.makedirs(output_dir, exist_ok=True)

    # ── Download ──
    downloaded_files = []

    if aweme_type == "video":
        video_url = data.get("videoUrl")
        if not video_url:
            error("API did not return video URL")
        safe_title = sanitize_filename(title) or f"video_{platform}"
        filename = f"{safe_title}.mp4"
        filepath = os.path.join(output_dir, filename)

        info(f"Type: Video")
        step("Downloading video...")

        if download_file(session, video_url, filepath):
            downloaded_files.append(filepath)

    elif aweme_type == "photo":
        image_urls = data.get("imageUrls") or []
        if not image_urls:
            error("API did not return image URLs")
        safe_title = sanitize_filename(title) or f"photo_{platform}"
        total = len(image_urls)
        info(f"Type: Photo (共 {total} 张)")

        for i, img_url in enumerate(image_urls, 1):
            ext = os.path.splitext(img_url.split("?")[0])[1] or ".jpg"
            filename = f"{safe_title}_{i}{ext}"
            filepath = os.path.join(output_dir, filename)

            step(f"Downloading image {i}/{total}...")
            if download_file(session, img_url, filepath):
                downloaded_files.append(filepath)

    else:
        error(f"Unknown awemeType: {aweme_type}")
    # ── Result ──
    if downloaded_files:
        print(f"\n{GREEN}{BOLD}✓ Download complete!{RESET}")
        for f in downloaded_files:
            size_mb = os.path.getsize(f) / (1024 * 1024)
            print(f"  {f} ({size_mb:.1f} MB)")
        sys.exit(0)
    else:
        print(f"\n{RED}{BOLD}✗ Download failed{RESET}")
if __name__ == "__main__":
    main()
