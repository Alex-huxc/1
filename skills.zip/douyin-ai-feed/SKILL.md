---
name: douyin-ai-feed
description: AI抖音信息源 — 每日自动扫描抖音 AI 相关作品，按互动量（点赞/分享/评论）筛选最火内容，智能聚类生成精美 HTML 日报，支持封面图、数据指标和每日订阅。当用户需要 AI 抖音日报、抖音AI热点、AI抖音内容、抖音信息源、douyin ai feed 时使用。
---

# AI抖音信息源

每日自动扫描抖音 AI 相关作品，按互动量（点赞/分享/评论）筛选最火内容，智能聚类后生成精美 HTML 日报。

---

## 能力概述

- **爆款发现**：按关键词搜索抖音 AI 作品，按互动量筛选最火内容
- **智能聚类**：自动从当天内容中发现话题方向，每天的分类由内容决定
- **终端表格**：分类 + 标题 + 作者 + 点赞/分享/评论数，一目了然
- **可视化日报**：深色主题 HTML（抖音青色风格），封面图、互动数据、作品直链、日期导航
- **一键订阅**：`--subscribe` 开启每日自动产出，日报自动攒在本地

---

## 使用方式

```bash
# 生成今日爆款日报（默认关键词：AI）
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py"

# 自定义关键词
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py" --keyword "ChatGPT"

# 查看历史某天
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py" --date 2026-06-09

# 指定时间范围（开始时间含，结束时间不含）
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py" --start-time 2026-06-09 --end-time 2026-06-10

# 订阅 / 取消订阅
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py" --subscribe
python3 "$SKILL_PATH/scripts/fetch_douyin_ai.py" --unsubscribe
```

生成的 HTML 日报保存在 `~/Downloads/QoderReports/`，自动浏览器打开。终端同步输出分类作品表格。

---

## 🔑 鉴权

---

## 参数说明

| 参数            | 说明                        | 默认值                     |
| --------------- | --------------------------- | -------------------------- |
| `--keyword`     | 搜索关键词                  | `AI`                       |
| `--page-size`   | 每页条数                    | `50`                       |
| `--date`        | 指定日期 YYYY-MM-DD         | 今天                       |
| `--start-time`  | 开始时间 YYYY-MM-DD（含）   | 根据 --date 自动计算       |
| `--end-time`    | 结束时间 YYYY-MM-DD（不含） | 根据 --date 自动计算       |
| `--output-dir`  | 输出目录                    | `~/Downloads/QoderReports` |
| `--subscribe`   | 安装每日定时任务 (16:00)    | —                          |
| `--unsubscribe` | 卸载定时任务                | —                          |
| `--no-open`     | 不自动打开浏览器            | —                          |

---

## 依赖

```bash
pip3 install requests
```

---

## 常见问题

**Q：日报里的分类是怎么来的？**
A：完全由当天内容决定。从作品的 type/topic 标签中自动识别聚类，每天的热点方向不同。

**Q：怎么看到更多作品？**
A：用 `--page-size 100` 增大单次查询数量。

**Q：订阅后日报存在哪？**
A：默认 `~/Downloads/QoderReports/`，文件名格式 `抖音AI日报_2026-06-10.html`。

