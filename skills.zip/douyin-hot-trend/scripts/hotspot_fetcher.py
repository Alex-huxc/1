#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音热榜数据获取脚本

功能：调用红狐数据热榜API获取抖音实时热点数据
接口：https://redfox.hk/story/api/hotSpot/getListByPlatform
参数：platform=2, source=抖音热榜-GitHub, startDate, endDate（可选）
方法：GET
认证：X-API-KEY（三级回退：环境变量 → shell配置文件 → 提示用户配置）
"""

import json
import os
import sys
import re
from datetime import datetime, timedelta

import requests


def get_api_key(cli_key=None):
    """Get API key from shared module."""
    from data_source import get_api_key as _get_ak
    return _get_ak(cli_key)


def fetch_douyin_hotspot(start_date=None, end_date=None, days=None):
    """
    获取抖音热榜数据

    使用原生 requests 发起请求，X-API-KEY 通过三级回退获取

    Args:
        start_date: 开始日期，格式 YYYY-MM-DD
        end_date: 结束日期，格式 YYYY-MM-DD
        days: 查询天数，如7表示近7天，30表示近30天

    Returns:
        None (结果直接打印到标准输出)
    """

    credential = get_api_key()

    # 构建请求URL
    url = ""  # Using data_source

    # 构建请求参数
    params = {
        "platform": 2,
        "source": "抖音热榜-GitHub"
    }

    # 处理日期参数
    query_type = "实时"

    if days:
        today = datetime.now().date()
        end_date_obj = today
        start_date_obj = today - timedelta(days=days)
        params["startDate"] = start_date_obj.strftime("%Y-%m-%d")
        params["endDate"] = end_date_obj.strftime("%Y-%m-%d")
        query_type = f"近{days}天"

    if start_date and end_date:
        params["startDate"] = start_date
        params["endDate"] = end_date
        query_type = f"{start_date} 至 {end_date}"

    # 构建请求头
    headers = {
        "X-API-KEY": (credential if credential else ""),
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    try:
        response = requests.get(url, params=params, headers=headers, timeout=30)

        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: {response.status_code}, {response.text}")

        api_response = response.json()

        # 处理不同的响应格式
        if isinstance(api_response, dict):
            if "data" in api_response:
                data = api_response["data"]
            elif "list" in api_response:
                data = api_response["list"]
            else:
                data = []
        elif isinstance(api_response, list):
            data = api_response
        else:
            data = []

        # 提取并格式化热榜数据
        if isinstance(data, list):
            now = datetime.now()
            fetch_time = now.strftime("%Y-%m-%d %H:00")

            result = {
                "fetch_time": fetch_time,
                "query_type": query_type,
                "start_date": start_date,
                "end_date": end_date,
                "hot_list": []
            }
            for item in data:
                # 处理标题：去除所有空格（半角空格、全角空格、制表符、换行符等）
                title = item.get("title", "")
                if title:
                    title = ''.join(title.split())
                result["hot_list"].append({
                    "index": item.get("index"),
                    "title": title,
                    "hotCount": item.get("hotCount", ""),
                    "url": item.get("url", "")
                })
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(json.dumps([], ensure_ascii=False))

    except requests.exceptions.RequestException as e:
        error_msg = {"error": f"请求失败: {str(e)}"}
        print(json.dumps(error_msg, ensure_ascii=False))
    except Exception as e:
        error_msg = {"error": f"错误: {str(e)}"}
        print(json.dumps(error_msg, ensure_ascii=False))
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='获取抖音热榜数据')
    parser.add_argument('--start-date', type=str, help='开始日期，格式 YYYY-MM-DD')
    parser.add_argument('--end-date', type=str, help='结束日期，格式 YYYY-MM-DD')
    parser.add_argument('--days', type=int, help='查询天数，如7表示近7天，30表示近30天')

    args = parser.parse_args()

    fetch_douyin_hotspot(
        start_date=args.start_date,
        end_date=args.end_date,
        days=args.days
    )
