#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""抖音涨粉账号推荐数据获取脚本

通过红狐数据API获取抖音涨粉榜数据，支持日榜/周榜/月榜，27个分类查询。
使用原生 urllib 发起请求，API Key 从环境变量 REDFOX_API_KEY 读取。

用法:
    python scripts/gzh_growth_fetcher.py --rank_type day --keyword 科技 --top_n 50
    python scripts/gzh_growth_fetcher.py --rank_type week --category 数码科技
    python scripts/gzh_growth_fetcher.py --rank_type month --category 全部 --top_n 50
    python scripts/gzh_growth_fetcher.py --list_categories
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from urllib.parse import quote

# Windows 终端强制 UTF-8 输出，避免 GBK 编码错误
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")


# ===== 常量 =====
API_URL = ""  # Uses data_source (set REDFOX_API_BASE env var)  # Now using shared data_source module (set via REDFOX_API_BASE env var)
SOURCE = "抖音涨粉账号推荐-GitHub"
SKILL_ID = "7637816739572727835"

# Shell 配置文件候选列表（按优先级）
SHELL_RC_FILES = [
    os.path.expanduser("~/.zshrc"),
    os.path.expanduser("~/.bashrc"),
    os.path.expanduser("~/.bash_profile"),
    os.path.expanduser("~/.profile"),
]


def _get_api_key():
    """获取 REDFOX_API_KEY，优先级：环境变量 > shell 配置文件 > 提示配置"""
    # 1. 优先从当前环境变量获取
    key = os.environ.get("REDFOX_API_KEY", "").strip()
    if key:
        return key

    # 2. 尝试从 shell 配置文件中读取
    import re
    pattern = re.compile(r'^\s*export\s+REDFOX_API_KEY\s*=\s*["\']?([^"\';\s]+)["\']?', re.MULTILINE)
    for rc_file in SHELL_RC_FILES:
        if os.path.isfile(rc_file):
            try:
                with open(rc_file, "r", encoding="utf-8") as f:
                    content = f.read()
                match = pattern.search(content)
                if match:
                    key = match.group(1).strip()
                    if key:
                        os.environ["REDFOX_API_KEY"] = key
                        return key
            except Exception:
                continue

    # 3. 未找到，提示用户配置
    raise ValueError(
        "REDFOX_API_KEY not configured. The script requires this environment variable to function."
    )\n"

    )

CATEGORIES = [
    "全部", "个人才艺", "生活vlog", "财富理财", "二次元", "居家装修",
    "学习教育", "小剧场", "数码科技", "旅行", "美食", "化妆美容",
    "动物", "亲子", "汽车", "情感", "三农", "健康医学",
    "潮流风尚", "舞蹈才艺", "颜值造型", "人文", "音乐", "影视",
    "身体锻炼", "体育", "明星娱乐", "游戏"
]

RANK_TYPE_MAP = {
    "day": "日榜",
    "week": "周榜",
    "month": "月榜"
}

DATE_TYPE_MAP = {
    "day": 1,
    "week": 2,
    "month": 3
}

# 榜单更新时间规则
DAY_UPDATE_HOUR = 18
DAY_UPDATE_MINUTE = 0
MONTH_UPDATE_DAY = 3
MONTH_UPDATE_HOUR = 18
MONTH_UPDATE_MINUTE = 0

DATA_CACHE_FILE = os.path.join(os.path.expanduser("~"), ".workbuddy", "cache", "dy_rise_ranking_data.json")

BILL_NOTE_TEMPLATES = {
    "day": "💡 榜单说明：抖音日榜每日18:00更新前一日数据，本次排名数据的获取时间为{fetch_date}，与实时数据存在差异。",
    "week": "💡 榜单说明：抖音周榜每周一18:00更新前一周数据，本次排名数据的获取时间为{fetch_date}，与实时数据存在差异。",
    "month": "💡 榜单说明：抖音月榜每月3号18:00更新上一月数据，本次排名数据的获取时间为{fetch_date}，与实时数据存在差异。",
}

# 日期查询范围限制
DAY_MAX_DAYS_BACK = 7
WEEK_MAX_WEEKS_BACK = 3
MONTH_MAX_MONTHS_BACK = 3


# ===== 日期计算 =====
def _is_after_day_update(now=None):
    """判断当前时间是否已过日榜/周榜更新时间(18:00)"""
    if now is None:
        now = datetime.now()
    cutoff = now.replace(hour=DAY_UPDATE_HOUR, minute=DAY_UPDATE_MINUTE, second=0, microsecond=0)
    return now >= cutoff


def _is_after_month_update(now=None):
    """判断当前时间是否已过月榜更新时间(当月3号18:00)"""
    if now is None:
        now = datetime.now()
    cutoff = now.replace(day=MONTH_UPDATE_DAY, hour=MONTH_UPDATE_HOUR,
                         minute=MONTH_UPDATE_MINUTE, second=0, microsecond=0)
    return now >= cutoff


def get_latest_query_date(rank_type="day"):
    """获取最新可查询的榜单日期

    Args:
        rank_type: day/week/month

    Returns:
        str: 查询日期字符串 (yyyy-MM-dd)
    """
    now = datetime.now()

    if rank_type == "day":
        if _is_after_day_update(now):
            target = now - timedelta(days=1)
        else:
            target = now - timedelta(days=2)
        return target.strftime("%Y-%m-%d")

    elif rank_type == "week":
        weekday = now.weekday()
        this_monday = now - timedelta(days=weekday)
        if _is_after_day_update(now):
            return this_monday.strftime("%Y-%m-%d")
        else:
            last_monday = this_monday - timedelta(weeks=1)
            return last_monday.strftime("%Y-%m-%d")

    elif rank_type == "month":
        if _is_after_month_update(now):
            if now.month == 1:
                return datetime(now.year - 1, 12, 1).strftime("%Y-%m-%d")
            else:
                return datetime(now.year, now.month - 1, 1).strftime("%Y-%m-%d")
        else:
            if now.month == 1:
                return datetime(now.year - 1, 11, 1).strftime("%Y-%m-%d")
            elif now.month == 2:
                return datetime(now.year - 1, 12, 1).strftime("%Y-%m-%d")
            else:
                return datetime(now.year, now.month - 2, 1).strftime("%Y-%m-%d")

    return now.strftime("%Y-%m-%d")


def get_earliest_query_date(rank_type="day"):
    """获取可查询的最早日期（限制范围）

    Args:
        rank_type: day/week/month

    Returns:
        str: 最早可查询日期字符串 (yyyy-MM-dd)
    """
    now = datetime.now()

    if rank_type == "day":
        earliest = now - timedelta(days=DAY_MAX_DAYS_BACK)
        return earliest.strftime("%Y-%m-%d")

    elif rank_type == "week":
        weekday = now.weekday()
        this_monday = now - timedelta(days=weekday)
        earliest_monday = this_monday - timedelta(weeks=WEEK_MAX_WEEKS_BACK)
        return earliest_monday.strftime("%Y-%m-%d")

    elif rank_type == "month":
        m = now.month
        y = now.year
        m -= MONTH_MAX_MONTHS_BACK
        while m <= 0:
            m += 12
            y -= 1
        return datetime(y, m, 1).strftime("%Y-%m-%d")

    return now.strftime("%Y-%m-%d")


def validate_and_adjust_date(rank_type, user_date_str):
    """验证用户指定的日期是否在可查询范围内，超出范围则自动调整

    Args:
        rank_type: day/week/month
        user_date_str: 用户指定的日期 (yyyy-MM-dd)

    Returns:
        dict: {original_date, adjusted_date, is_adjusted, reminder}
    """
    user_date = datetime.strptime(user_date_str, "%Y-%m-%d")
    latest = datetime.strptime(get_latest_query_date(rank_type), "%Y-%m-%d")
    earliest = datetime.strptime(get_earliest_query_date(rank_type), "%Y-%m-%d")

    if earliest <= user_date <= latest:
        return {
            "original_date": user_date_str,
            "adjusted_date": user_date_str,
            "is_adjusted": False,
            "reminder": ""
        }

    if user_date > latest:
        adjusted = latest.strftime("%Y-%m-%d")
    else:
        adjusted = earliest.strftime("%Y-%m-%d")

    reminder = (
        '非常抱歉🙏，目前抖音榜单最多支持回溯「近7天的日榜/近3周的周榜/近3个月的月榜」，'
        '我已为您查询最接近您需求的时间范围~'
    )

    return {
        "original_date": user_date_str,
        "adjusted_date": adjusted,
        "is_adjusted": True,
        "reminder": reminder
    }


def get_data_time_range(rank_type, rank_date):
    """根据榜单类型和查询日期生成数据统计时间周期描述"""
    import calendar
    date_obj = datetime.strptime(rank_date, "%Y-%m-%d")
    if rank_type == "day":
        return rank_date
    elif rank_type == "week":
        end_date = date_obj + timedelta(days=6)
        return f"{date_obj.strftime('%Y-%m-%d')}至{end_date.strftime('%Y-%m-%d')}"
    elif rank_type == "month":
        last_day = calendar.monthrange(date_obj.year, date_obj.month)[1]
        return f"{date_obj.strftime('%Y-%m')}-01至{date_obj.strftime('%Y-%m')}-{last_day:02d}"
    return rank_date


def get_today_query_reminder(rank_type="day"):
    """当用户查询今日日榜但数据未更新时，生成提醒"""
    if rank_type == "day" and not _is_after_day_update():
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        return (
            '日榜数据暂未更新，将为您查询最接近您需求日期的榜单数据~\n'
            f'推荐查询昨日更新的最新榜单（{yesterday}日榜）'
        )
    return ""


# ===== API调用 =====
def fetch_ranking_data(rank_type="day", rank_date=None, category="全部"):
    """获取抖音涨粉账号推荐数据

    Args:
        rank_type: day/week/month
        rank_date: 查询日期 (yyyy-MM-dd)，None则自动计算
        category: 分类名称

    Returns:
        list: API返回的data数组
    """
    if rank_date is None:
        rank_date = get_latest_query_date(rank_type)

    # 获取凭证
    credential = _get_api_key()

    date_type = DATE_TYPE_MAP.get(rank_type, 1)

    payload = {
        "dateType": date_type,
        "rankDate": rank_date,
        "category": category,
        "source": "dy_rise_fans_rank"
    }

    headers = {
        "Content-Type": "application/json",
        "X-API-KEY": credential
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(API_URL, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            if resp.status >= 400:
                raise ValueError(
        "REDFOX_API_KEY not configured. The script requires this environment variable to function."
    )}")
            return
        elif isinstance(matched, list):
            print(f"关键词'{args.keyword}'匹配到多个分类：{', '.join(matched)}，请指定更精确的分类名")
            return
        else:
            category = matched
            print(f"根据关键词【{args.keyword}】匹配到分类：【{category}】")

    # 确定查询日期
    rank_label = RANK_TYPE_MAP.get(args.rank_type, "日榜")
    print(f"正在获取抖音涨粉账号推荐{rank_label}数据...")
    print(f"当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    reminder = ""

    if args.rank_date:
        validation = validate_and_adjust_date(args.rank_type, args.rank_date)
        rank_date = validation["adjusted_date"]
        if validation["is_adjusted"]:
            reminder = validation["reminder"]
            print(f"用户指定日期: {args.rank_date} -> 调整为: {rank_date}")
            print(f"提醒: {reminder}")
    else:
        rank_date = get_latest_query_date(args.rank_type)
        today_reminder = get_today_query_reminder(args.rank_type)
        if today_reminder:
            reminder = today_reminder
            print(f"提醒: {reminder}")

    print(f"榜单类型: {rank_label}")
    print(f"查询日期: {rank_date}")
    print(f"分类: {category}")
    print("-" * 60)

    try:
        data_list = fetch_ranking_data(
            rank_type=args.rank_type,
            rank_date=rank_date,
            category=category,
        )
    except Exception as e:
        print(f"错误: {e}")
        return

    if not data_list:
        print("未获取到数据")
        return

    # 格式化输出
    update_time = get_update_time_label(args.rank_type, rank_date)
    time_range = get_data_time_range(args.rank_type, rank_date)
    fetch_date = rank_date
    data_description = BILL_NOTE_TEMPLATES.get(args.rank_type, BILL_NOTE_TEMPLATES["day"]).format(fetch_date=fetch_date)

    output = {
        "status": "success",
        "rank_type": args.rank_type,
        "rank_label": rank_label,
        "rank_date": rank_date,
        "category": category,
        "data_description": data_description,
        "total_count": len(data_list),
        "top_n": min(args.top_n, len(data_list)),
        "update_time": update_time,
        "time_range": time_range,
        "reminder": reminder,
        "ranking_table": format_ranking_table(data_list, args.top_n, args.start),
        "analysis": format_analysis(data_list, args.rank_type),
        "account_list": data_list,
    }

    # 自动写入本地缓存文件，供gen_gzh_html.py直接读取
    try:
        os.makedirs(os.path.dirname(DATA_CACHE_FILE), exist_ok=True)
        with open(DATA_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

    # 原始输出
    if args.raw:
        print(json.dumps(output, ensure_ascii=False, indent=2))
        return

    print(json.dumps(output, ensure_ascii=False))


if __name__ == "__main__":
    main()
