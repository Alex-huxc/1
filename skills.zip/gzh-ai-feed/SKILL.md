---
name: gzh-ai-feed
description: AI公众号信息源 — Daily scan of AI WeChat public accounts, finding the hottest articles by read count, auto-clustering into topics, and generating a styled HTML report with cover images, metrics, search, and subscription support. Use when the user wants AI daily reports, 公众号爆款, AI content curation, 每日AI热点, or 公众号日报.
---

# AI公众号信息源

每日自动扫描全网 AI 公众号，按阅读量找出最火的爆款内容，智能聚类后生成精美 HTML 日报。

---

## 能力概述

- **爆款发现**：从 200+ 篇 AI 公众号文章中，按阅读量筛选最火的热门内容
- **智能聚类**：自动从当天内容中发现话题方向（Agent、大模型、AI绘画...），每天的分类由内容决定
- **终端表格**：分类 + 标题 + 作者 + 阅读/点赞/评论数，一目了然
- **可视化日报**：深色主题 HTML，封面图、互动数据、文章直链、日期导航
- **全库搜索**：日报页面内置搜索框，通过本地代理服务实时检索全量文章库（模糊匹配，与日期无关）
- **一键订阅**：`--subscribe` 开启每日自动产出，日报自动攒在本地文件夹

---

## 使用方式

```bash
# 生成今日爆款日报
python3 "$SKILL_PATH/assets/daily_report.py"

# 自定义关注方向
python3 "$SKILL_PATH/assets/daily_report.py" --keywords "AI Agent,RAG,LangChain,Prompt"

# 查看历史某天
python3 "$SKILL_PATH/assets/daily_report.py" --date 2026-05-26

# 订阅 / 取消订阅
python3 "$SKILL_PATH/assets/daily_report.py" --subscribe
python3 "$SKILL_PATH/assets/daily_report.py" --unsubscribe
```

生成的 HTML 日报保存在 `~/Downloads/QoderReports/`，自动浏览器打开。终端同步输出分类文章表格。

---

## 首次使用

先配置 API Key，然后运行：

```bash
# 方式一：环境变量（推荐）

# 方式二：配置文件
mkdir -p ~/.qoder/apis
echo '{"api_key":"ak_你的密钥"}' > ~/.qoder/apis/redfox.json

# 然后运行
python3 "$SKILL_PATH/assets/daily_report.py"
```

---

## 后续使用

| 方式 | 命令 |
|------|------|
| 命令行参数 | `--api-key ak_你的密钥` |
| 配置文件 | `echo '{"api_key":"ak_你的密钥"}' > ~/.qoder/apis/redfox.json` |

---

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--keywords` | 关注的话题方向，逗号分隔 | `AI,人工智能,大模型,GPT,Agent,AI绘画` |
| `--count` | 扫描文章数量 | `200` |
| `--date` | 指定日期 YYYY-MM-DD | 今天 |
| `--output-dir` | 输出目录 | `~/Downloads/QoderReports` |
| `--api-key` | 指定 API Key | — |
| `--subscribe` | 开启每日订阅 | — |
| `--unsubscribe` | 关闭每日订阅 | — |
| `--no-open` | 不自动打开浏览器 | — |

---

## 依赖

```bash
pip3 install requests
```

---

## 常见问题

**Q：日报里的分类是怎么来的？**
A：完全由当天内容决定。从文章话题、分类标签和标题关键词中自动识别聚类，每天的热点方向不同。

**Q：怎么看到更多文章？**
A：用 `--count 300` 扩大扫描范围，或通过 `--keywords` 添加更多关注方向。

**Q：HTML 搜索怎么用？**
A：日报页面内置搜索框，脚本启动时会自动拉起本地代理服务（端口 8765），在浏览器中直接搜索全量文章库。

**Q：搜索和日报是什么关系？**
A：日报是特定日期的聚类展示；搜索是实时查询全库内容（模糊匹配，与日期无关），适合找特定话题的任意日期文章。

**Q：订阅后日报存在哪？**
A：默认 `~/Downloads/QoderReports/`，文件名格式 `AI日报_2026-05-27.html`。

**Q：额度用完怎么办？**
