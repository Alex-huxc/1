﻿#!/usr/bin/env python3
"""
Shared data source module — Hybrid API/Mock mode for redfox-community skills.

Mode selection (via DATA_SOURCE env var):
  "auto" (default): Try API_BASE first, fall back to mock data
  "api"           : Force API mode (fail if API_BASE not set)
  "mock"          : Force local mock data

API_BASE env var: Sets the backend API endpoint (default: https://redfox.hk/story/api)
"""

import os
import json
import sys
import time
import random
import urllib.request
import urllib.error

# ─── Configuration ─────────────────────────────────────────────────────────────

DATA_SOURCE = os.environ.get("DATA_SOURCE", "auto").lower()
API_BASE = os.environ.get("REDFOX_API_BASE", "")

# Always try to read from old env var for backwards compatibility
API_KEY = os.environ.get("REDFOX_API_KEY", "") or None


def get_api_key():
    """Backward-compatible API key getter."""
    return API_KEY


def get_api_base():
    """Get the configured API base URL."""
    return API_BASE


def get_data_source():
    """Get current data source mode."""
    return DATA_SOURCE


def can_use_api():
    """Check if API mode is available."""
    if DATA_SOURCE == "mock":
        return False
    if API_BASE or os.environ.get("REDFOX_API_BASE"):
        return True
    if DATA_SOURCE == "auto" and os.environ.get("REDFOX_API_BASE"):
        return True
    if DATA_SOURCE == "api" and not API_BASE:
        print("[data_source] ⚠️  DATA_SOURCE=api but REDFOX_API_BASE not set, falling back to mock")
        return False
    return False


# ─── HTTP Request helper ──────────────────────────────────────────────────────

def api_post(endpoint: str, payload: dict = None) -> dict:
    """Send a POST request to the API."""
    base = API_BASE or os.environ.get("REDFOX_API_BASE", "")
    if not base:
        raise ConnectionError("API_BASE not configured")
    
    url = base.rstrip("/") + "/" + endpoint.lstrip("/")
    data = json.dumps(payload or {}).encode("utf-8")
    
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    if API_KEY:
        req.add_header("X-API-KEY", API_KEY)
    
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise ConnectionError(f"API error {e.code}: {body}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"API unreachable: {e.reason}")


def api_get(endpoint: str, params: dict = None) -> dict:
    """Send a GET request to the API."""
    base = API_BASE or os.environ.get("REDFOX_API_BASE", "")
    if not base:
        raise ConnectionError("API_BASE not configured")
    
    url = base.rstrip("/") + "/" + endpoint.lstrip("/")
    if params:
        import urllib.parse
        url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v})
    
    req = urllib.request.Request(url, method="GET")
    if API_KEY:
        req.add_header("X-API-KEY", API_KEY)
    
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise ConnectionError(f"API error {e.code}: {body}")
    except urllib.error.URLError as e:
        raise ConnectionError(f"API unreachable: {e.reason}")


# ─── Fetch with auto-fallback ─────────────────────────────────────────────────

def fetch(endpoint: str, payload: dict = None, mock_data_func=None, **mock_kwargs):
    """
    Fetch data with auto-fallback.
    
    Args:
        endpoint: API endpoint path (e.g. "dy/search/search")
        payload: POST body dict
        mock_data_func: Function that returns mock data dict
        **mock_kwargs: Passed to mock_data_func
    
    Returns:
        dict with at least {"code": 0, "data": ...}
    """
    # Try API first
    if can_use_api():
        try:
            result = api_post(endpoint, payload)
            print(f"[data_source] ✅ API: {endpoint}")
            return result
        except Exception as e:
            print(f"[data_source] ⚠️  API unavailable ({e}), using mock data")
    
    # Fallback to mock
    if mock_data_func:
        print(f"[data_source] 🎲 Mock: {endpoint}")
        return mock_data_func(**mock_kwargs)
    
    print(f"[data_source] ❌ No data source available for {endpoint}")
    return {"code": -1, "data": [], "msg": "No data source configured"}


# ─── Mock data helpers ────────────────────────────────────────────────────────

def _random_date(days_ago: int = 7) -> str:
    """Generate a random date string YYYY-MM-DD within the last N days."""
    from datetime import datetime, timedelta
    days = random.randint(0, days_ago)
    d = datetime.now() - timedelta(days=days)
    return d.strftime("%Y-%m-%d")


def _random_datetime(days_ago: int = 7) -> str:
    """Generate a random datetime string."""
    from datetime import datetime, timedelta
    days = random.randint(0, days_ago)
    hours = random.randint(0, 23)
    d = datetime.now() - timedelta(days=days, hours=hours)
    return d.strftime("%Y-%m-%d %H:%M:%S")


def _pick(items: list):
    return random.choice(items)


def _rand_count() -> int:
    return random.randint(100, 99999)


def _rand_followers() -> int:
    return random.randint(1000, 9999999)


# ═══════════════════════════════════════════════════════════════════════════════
# Mock data generators — each returns a dict matching the real API response
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Platform account names ────────────────────────────────────────────────────

DOUYIN_ACCOUNTS = [
    "科技新视线", "AI前沿观察", "数码测评哥", "互联网那点事", "创业加油站",
    "职场进化论", "财经每日说", "潮流科技控", "生活研究所", "知识星球",
    "人工智能日报", "效率工具控", "产品经理日记", "运营增长笔记", "数据可视化"
]

WECHAT_ACCOUNTS = [
    "人民日报", "新华社", "央视新闻", "南方周末", "新周刊",
    "虎嗅APP", "36氪", "钛媒体", "极客公园", "爱范儿",
    "槽值", "网易公开课", "知乎日报", "豆瓣读书", "三联生活周刊"
]

XHS_ACCOUNTS = [
    "小A的成长日记", "美妆种草机", "穿搭研究所", "旅行日记本", "美食厨房",
    "读书笔记", "瑜伽生活", "摄影日记", "家居灵感", "健身打卡"
]

BIZ_KEYWORDS = [
    "AI", "ChatGPT", "人工智能", "大模型", "数字化转型",
    "新消费", "新能源", "跨境电商", "直播带货", "短视频",
    "私域运营", "元宇宙", "Web3", "SaaS", "智能制造"
]

# ─── Mock generators for each endpoint type ────────────────────────────────────

def mock_douyin_search(keyword="AI", page_size=20):
    """Mock response for /dy/search/search"""
    articles = []
    for i in range(min(page_size, 15)):
        articles.append({
            "title": f"{keyword}相关：{_pick(BIZ_KEYWORDS)}趋势分析第{i+1}期",
            "accountName": _pick(DOUYIN_ACCOUNTS),
            "likeCount": _rand_count(),
            "commentCount": _rand_count() // 10,
            "shareCount": _rand_count() // 20,
            "collectCount": _rand_count() // 5,
            "workUrl": f"https://www.douyin.com/video/{random.randint(7000000000000000000, 9999999999999999999)}",
            "publishTime": _random_datetime(),
            "followerCount": _rand_followers(),
        })
    articles.sort(key=lambda x: x["likeCount"], reverse=True)
    return {"code": 0, "data": {"articles": articles, "total": len(articles)}}


def mock_douyin_hot():
    """Mock response for /dy/hotSpot/list"""
    topics = []
    categories = ["热榜", "娱乐", "科技", "社会", "体育", "财经", "教育"]
    for i in range(20):
        topics.append({
            "rank": i + 1,
            "title": f"热点话题 #{i+1}：{_pick(BIZ_KEYWORDS)}最新动态",
            "hotCount": str(random.randint(500000, 9999999)),
            "category": _pick(categories),
            "url": f"https://www.douyin.com/hot/{i+1}",
        })
    return {"code": 0, "data": topics}


def mock_douyin_daily(keyword="AI", page_size=50):
    """Mock response for /dy/likesRank"""
    articles = []
    for i in range(min(page_size, 20)):
        articles.append({
            "title": f"🔥 {keyword}热门作品 #{i+1}",
            "accountName": _pick(DOUYIN_ACCOUNTS),
            "likeCount": _rand_count(),
            "commentCount": _rand_count() // 10,
            "shareCount": _rand_count() // 20,
            "collectCount": _rand_count() // 5,
            "workUrl": f"https://www.douyin.com/video/{random.randint(7000000000000000000, 9999999999999999999)}",
            "publishTime": _random_datetime(),
            "followerCount": _rand_followers(),
        })
    articles.sort(key=lambda x: x["likeCount"], reverse=True)
    return {"code": 0, "data": articles}


def mock_wechat_search(keyword="AI", days=30):
    """Mock response for /gzh/search"""
    articles = []
    for i in range(20):
        articles.append({
            "title": f"{keyword}深度解读：{_pick(BIZ_KEYWORDS)}行业报告{i+1}",
            "accountName": _pick(WECHAT_ACCOUNTS),
            "readCount": _rand_count(),
            "likeCount": _rand_count() // 50,
            "commentCount": _rand_count() // 200,
            "url": f"https://mp.weixin.qq.com/s/{random.randint(1000000000, 9999999999)}",
            "publishTime": _random_datetime(),
            "digest": f"本文深入分析了{keyword}领域的最新发展趋势，包括{_pick(BIZ_KEYWORDS)}、{_pick(BIZ_KEYWORDS)}等热点话题。" 
        })
    return {"code": 0, "data": {"articles": articles, "total": len(articles)}}


def mock_xiaohongshu_search(keyword="AI"):
    """Mock response for /xhs/search"""
    notes = []
    for i in range(15):
        notes.append({
            "title": f"{keyword}｜{_pick(BIZ_KEYWORDS)}干货分享第{i+1}弹",
            "author": _pick(XHS_ACCOUNTS),
            "likedCount": str(_rand_count()),
            "collectedCount": str(_rand_count() // 3),
            "commentCount": str(_rand_count() // 10),
            "noteUrl": f"https://www.xiaohongshu.com/explore/{random.randint(6000000000000000000, 9999999999999999999)}",
            "time": _random_datetime(),
            "desc": f"今天和大家分享关于{keyword}的一些心得和体会，希望对大家有帮助～",
            "type": _pick(["图文", "视频"]),
        })
    return {"code": 0, "data": notes}


def mock_trending_hub():
    """Mock response for /hotSpot/list"""
    platforms = ["抖音", "微博", "知乎", "百度", "B站"]
    topics = []
    for i in range(30):
        topics.append({
            "platform": _pick(platforms),
            "rank": i + 1,
            "title": f"🔥 {_pick(BIZ_KEYWORDS)}话题 #热搜{i+1}",
            "hotCount": str(random.randint(100000, 9999999)),
            "url": f"https://example.com/hot/{i+1}",
        })
    return {"code": 0, "data": topics}


def mock_last30days(keyword="AI", platforms=None):
    """Mock response for multi-platform 30-day data"""
    if platforms is None:
        platforms = ["xhs", "dy", "gzh"]
    
    result = {}
    for platform in platforms:
        items = []
        for i in range(10):
            base = {
                "title": f"{keyword}趋势观察#{i+1}",
                "url": f"https://example.com/{platform}/{i}",
                "publishTime": _random_datetime(30),
                "likeCount": str(_rand_count()),
                "commentCount": str(_rand_count() // 10),
                "collectCount": str(_rand_count() // 5),
            }
            if platform == "dy":
                base["accountName"] = _pick(DOUYIN_ACCOUNTS)
                base["followerCount"] = str(_rand_followers())
            elif platform == "gzh":
                base["accountName"] = _pick(WECHAT_ACCOUNTS)
                base["readCount"] = str(_rand_count())
            elif platform == "xhs":
                base["author"] = _pick(XHS_ACCOUNTS)
                base["likedCount"] = str(_rand_count())
            items.append(base)
        
        result[platform] = {"items": items, "total": len(items)}
    
    return {"code": 0, "data": result}


def mock_douyin_user(account_name=None):
    """Mock response for /dyUser/info"""
    return {
        "code": 0,
        "data": {
            "accountName": account_name or _pick(DOUYIN_ACCOUNTS),
            "followerCount": _rand_followers(),
            "followingCount": random.randint(100, 5000),
            "workCount": random.randint(50, 999),
            "likeCount": _rand_count(),
            "redfoxIndex": random.randint(300, 950),
            "description": f"优质{_pick(['科技', '财经', '生活', '教育', '娱乐'])}领域创作者",
            "avatarUrl": "",
        }
    }


def mock_prohibited_words_check(text, platform="公众号"):
    """Mock response for /cozeSkill/check"""
    # Simple local keyword-based check
    sensitive_words = ["赌博", "色情", "暴力", "诈骗", "传销", "非法", "反动", "分裂", "吸毒", "枪支"]
    found = [w for w in sensitive_words if w in text]
    return {
        "code": 0,
        "data": {
            "hasSensitive": len(found) > 0,
            "sensitiveWords": found,
            "suggestion": "内容安全" if len(found) == 0 else "存在违禁词，请修改后发布",
        }
    }


# ─── Endpoint routing ─────────────────────────────────────────────────────────

MOCK_ROUTES = {
    "dy/search/search": mock_douyin_search,
    "dy/search/likesRank": mock_douyin_daily,
    "dy/hotSpot/list": mock_douyin_hot,
    "dy/hotSpot/search": mock_douyin_hot,
    "dyData/rank": mock_douyin_daily,
    "dyUser/info": mock_douyin_user,
    "dyUser/similar": lambda **k: mock_douyin_user(**k),
    "gzh/search": mock_wechat_search,
    "gzhData/articles": mock_wechat_search,
    "xhs/search": mock_xiaohongshu_search,
    "xhsData/rank": mock_xiaohongshu_search,
    "xhsUser/info": lambda **k: mock_douyin_user(**k),
    "xhsUser/similar": lambda **k: mock_douyin_user(**k),
    "hotSpot/list": mock_trending_hub,
    "hotKeyword/list": mock_trending_hub,
    "cn/list": mock_last30days,
    "cozeSkill/check": mock_prohibited_words_check,
    "cozeSkill/run": lambda **k: {"code": 0, "data": {"result": "ok"}},
    "skill/record/save": lambda **k: {"code": 0, "msg": "ok"},
}


def fetch_with_mock(endpoint: str, payload: dict = None, **kwargs):
    """
    Fetch with automatic API/MOCK switching.
    
    Args:
        endpoint: API path (e.g. "dy/search/search")
        payload: Request body dict
        **kwargs: Extra args for mock generator
    
    Returns:
        Parsed JSON dict
    """
    # Determine which mock function to use
    mock_func = None
    for route, func in MOCK_ROUTES.items():
        if endpoint.endswith(route) or endpoint == route:
            mock_func = func
            break
    
    if can_use_api():
        try:
            result = api_post(endpoint, payload)
            if isinstance(result, dict) and result.get("code") == 0:
                return result
            return result
        except Exception as e:
            if DATA_SOURCE == "api":
                raise
            print(f"[data_source] ⚠️  API {endpoint} unavailable ({e}), using mock")
    
    if mock_func:
        print(f"[data_source] 🎲 Mock data for {endpoint}")
        return mock_func(**kwargs)
    
    print(f"[data_source] ❌ No data source for {endpoint}")
    return {"code": -1, "data": [], "msg": "No data source configured"}
